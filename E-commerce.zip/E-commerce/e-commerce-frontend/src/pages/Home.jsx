import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { productAPI } from '../services/api';
import ProductCard from '../components/ProductCard';

import './Home.css';

const Home = () => {
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeaturedProducts = async () => {
      try {
        const response = await productAPI.getAllProducts(0, 6);
        setFeaturedProducts(response.data.content || response.data);
      } catch (error) {
        console.error('Error fetching products:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchFeaturedProducts();
  }, []);

  return (
    <div className="home">
      <div className="hero">
        <div className="container">
          <div className="hero-content">
            <h1>Welcome to SmartStore</h1>
            <p>Discover amazing products with personalized recommendations and seamless shopping experience</p>
            <Link to="/products" className="btn btn-primary">Shop Now</Link>
          </div>
        </div>
      </div>

      <div className="container">
        <div className="features">
          <div className="feature">
            <h3>Easy Shopping</h3>
            <p>Browse and purchase products with just a few clicks</p>
          </div>
          <div className="feature">
            <h3>Smart Recommendations</h3>
            <p>Get personalized product suggestions based on your preferences</p>
          </div>
          <div className="feature">
            <h3>Trusted Platform</h3>
            <p>Secure and reliable e-commerce platform for all users</p>
          </div>
        </div>


        
        <div className="featured-section">
          <h2>Featured Products</h2>
          {loading ? (
            <div className="loading">
              <div className="spinner"></div>
            </div>
          ) : (
            <div className="grid grid-3">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
          <div className="text-center mt-20">
            <Link to="/products" className="btn btn-primary">View All Products</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;