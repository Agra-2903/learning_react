import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { orderAPI } from '../services/api';
import './Orders.css';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await orderAPI.getUserOrders();
        setOrders(response.data);
      } catch (error) {
        console.error('Error fetching orders:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="orders-page">
      <div className="container">
        <h1>My Orders</h1>
        
        {location.state?.message && (
          <div className="alert alert-success">{location.state.message}</div>
        )}

        {orders.length === 0 ? (
          <div className="no-orders">
            <h2>No orders yet</h2>
            <p>Your order history will appear here</p>
          </div>
        ) : (
          <div className="orders-list">
            {orders.map((order) => (
              <div key={order.id} className="order-card card">
                <div className="order-header">
                  <div className="order-info">
                    <h3>Order #{order.id}</h3>
                    <p>{new Date(order.orderDate).toLocaleDateString()}</p>
                  </div>
                  <div className="order-summary">
                    <div className="order-total">${order.totalAmount}</div>
                    <span className={`order-status status-${order.status.toLowerCase()}`}>
                      {order.status}
                    </span>
                  </div>
                </div>
                
                <div className="order-items">
                  <h4>Items:</h4>
                  {order.orderItems?.map((item, index) => (
                    <div key={index} className="order-item">
                      <span>{item.productName} × {item.quantity}</span>
                      <span>${item.price}</span>
                    </div>
                  ))}
                  <div className="shipping-address">
                    <h4>Shipping Address:</h4>
                    <p>{order.shippingAddress}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Orders;