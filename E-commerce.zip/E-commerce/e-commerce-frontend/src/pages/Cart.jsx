import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { orderAPI } from '../services/api';
import ShippingForm from '../components/ShippingForm';
import './Cart.css';

const Cart = () => {
  const { cartItems, updateQuantity, removeFromCart, getTotalPrice, clearCart } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [showShippingForm, setShowShippingForm] = useState(false);

  const handlePlaceOrder = async (orderData) => {
    if (cartItems.length === 0) return;

    setLoading(true);
    try {
      console.log('Placing order with data:', orderData);
      const response = await orderAPI.placeOrder(orderData);
      console.log('Order response:', response.data);
      const { order, payment } = response.data;
      
      if (payment && payment.razorpayOrderId) {
        // Razorpay payment flow
        const options = {
          key: payment.razorpayKey,
          amount: payment.amount,
          currency: payment.currency,
          order_id: payment.razorpayOrderId,
          name: 'SmartStore',
          description: `Order #${order.id}`,
          handler: async (razorpayResponse) => {
            try {
              await orderAPI.confirmOrder(order.id);
              clearCart();
              setShowShippingForm(false);
              navigate('/orders', { 
                state: { message: 'Order placed and payment successful!' }
              });
            } catch (error) {
              console.error('Error confirming order:', error);
              alert('Payment successful but order confirmation failed. Please contact support.');
            }
          },
          modal: {
            ondismiss: () => {
              alert('Payment cancelled. Your order is in pending status.');
              setLoading(false);
            }
          }
        };
        
        const razorpay = new window.Razorpay(options);
        razorpay.open();
      } else {
        // Direct confirmation for non-payment orders
        await orderAPI.confirmOrder(order.id);
        clearCart();
        setShowShippingForm(false);
        navigate('/orders', { 
          state: { message: 'Order placed successfully!' }
        });
      }
    } catch (error) {
      console.error('Error placing order:', error);
      console.error('Error response:', error.response);
      const errorMessage = typeof error.response?.data === 'string' 
        ? error.response.data 
        : JSON.stringify(error.response?.data) || error.message || 'Failed to place order';
      
      if (errorMessage.includes('out of stock')) {
        alert('Some items in your cart are out of stock. Please update your cart and try again.');
        window.location.reload();
      } else {
        alert('Failed to place order: ' + errorMessage);
      }
    } finally {
      setLoading(false);
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="empty-cart">
        <div className="empty-cart-content">
          <h2>Your cart is empty</h2>
          <p>Add some products to get started</p>
          <button onClick={() => navigate('/products')} className="btn btn-primary">
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="cart-page">
      <div className="container">
        <h1>Shopping Cart</h1>
        
        <div className="cart-content card">
          <div className="cart-items">
            {cartItems.map((item) => (
              <div key={item.productId} className="cart-item">
                <img
                  src={item.imageUrl || 'https://via.placeholder.com/100x100?text=No+Image'}
                  alt={item.productName}
                  className="cart-item-image"
                />
                
                <div className="cart-item-info">
                  <h3>{item.productName}</h3>
                  <p>${item.price}</p>
                </div>
                
                <div className="quantity-controls">
                  <button onClick={() => updateQuantity(item.productId, item.quantity - 1)}>-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.productId, item.quantity + 1)}>+</button>
                </div>
                
                <div className="cart-item-total">
                  ${(item.price * item.quantity).toFixed(2)}
                </div>
                
                <button onClick={() => removeFromCart(item.productId)} className="btn btn-danger remove-btn">
                  Remove
                </button>
              </div>
            ))}
          </div>
          
          <div className="cart-footer">
            <div className="cart-total">
              <span>Total: ${getTotalPrice().toFixed(2)}</span>
            </div>
            
            <div className="cart-actions">
              <button onClick={() => navigate('/products')} className="btn btn-secondary">
                Continue Shopping
              </button>
              <button onClick={() => setShowShippingForm(true)} disabled={loading} className="btn btn-primary">
                Place Order
              </button>
            </div>
          </div>
        </div>
        
        {showShippingForm && (
          <ShippingForm
            onSubmit={handlePlaceOrder}
            onCancel={() => setShowShippingForm(false)}
            loading={loading}
          />
        )}
      </div>
    </div>
  );
};

export default Cart;