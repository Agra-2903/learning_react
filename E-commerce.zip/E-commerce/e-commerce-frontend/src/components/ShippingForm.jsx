import { useState } from 'react';
import './ShippingForm.css';

const ShippingForm = ({ onSubmit, onCancel, loading }) => {
  const [shippingAddress, setShippingAddress] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (shippingAddress.trim()) {
      onSubmit({ shippingAddress: shippingAddress.trim() });
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <h2>Shipping Information</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Shipping Address *</label>
            <textarea
              value={shippingAddress}
              onChange={(e) => setShippingAddress(e.target.value)}
              placeholder="Enter your complete shipping address..."
              rows="4"
              className="form-control"
              required
            />
          </div>
          <div className="form-actions">
            <button type="submit" disabled={loading || !shippingAddress.trim()} className="btn btn-primary">
              {loading ? 'Placing Order...' : 'Place Order'}
            </button>
            <button type="button" onClick={onCancel} className="btn btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ShippingForm;