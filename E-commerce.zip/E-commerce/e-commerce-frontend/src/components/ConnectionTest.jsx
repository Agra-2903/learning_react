import { useState } from 'react';
import { productAPI, authAPI } from '../services/api';

const ConnectionTest = () => {
  const [results, setResults] = useState({});
  const [testing, setTesting] = useState(false);

  const testConnections = async () => {
    setTesting(true);
    const testResults = {};

    // Test Product Service
    try {
      const response = await productAPI.getAllProducts(0, 1);
      testResults.products = { status: 'success', data: response.data };
    } catch (error) {
      testResults.products = { status: 'error', error: error.message };
    }

    // Test Auth Service (register endpoint)
    try {
      const response = await fetch('http://localhost:8080/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: 'test', email: 'test@test.com', password: 'test' })
      });
      testResults.auth = { status: response.ok ? 'success' : 'error', statusCode: response.status };
    } catch (error) {
      testResults.auth = { status: 'error', error: error.message };
    }

    setResults(testResults);
    setTesting(false);
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', margin: '20px', borderRadius: '8px' }}>
      <h3>Backend Connection Test</h3>
      <button onClick={testConnections} disabled={testing} className="btn btn-primary">
        {testing ? 'Testing...' : 'Test Connections'}
      </button>
      
      {Object.keys(results).length > 0 && (
        <div style={{ marginTop: '20px' }}>
          <h4>Results:</h4>
          <pre style={{ background: '#f5f5f5', padding: '10px', borderRadius: '4px' }}>
            {JSON.stringify(results, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
};

export default ConnectionTest;