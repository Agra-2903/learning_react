import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import './ProductCard.css';

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();
  const { isAuthenticated } = useAuth();

  const handleAddToCart = () => {
    if (isAuthenticated) {
      addToCart(product);
    }
  };

  return (
    <div className="product-card">
      <img
        src={product.imageUrl || 'https://via.placeholder.com/300x200?text=No+Image'}
        alt={product.name}
        className="product-image"
      />
      <div className="product-info">
        <h3 className="product-name">{product.name}</h3>
        <p className="product-description">{product.description}</p>
        <div className="product-meta">
          <span className="product-category">{product.category}</span>
          <span className="product-stock">Stock: {product.stock}</span>
        </div>
        <div className="product-footer">
          <span className="product-price">${product.price}</span>
          {isAuthenticated && product.stock > 0 && (
            <button onClick={handleAddToCart} className="btn btn-primary">
              Add to Cart
            </button>
          )}
        </div>
        {product.stock === 0 && (
          <div className="out-of-stock">Out of Stock</div>
        )}
      </div>
    </div>
  );
};

export default ProductCard;