import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('username');
      localStorage.removeItem('role');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  login: (credentials) => api.post('/api/auth/login', credentials),
  register: (userData) => api.post('/api/auth/register', userData),
};

export const productAPI = {
  getAllProducts: (page = 0, size = 100) => api.get(`/api/products?page=${page}&size=${size}`),
  getProductById: (id) => api.get(`/api/products/${id}`),
  getProductByName: (name) => api.get(`/api/products/by-name/${name}`),
  createProduct: (product) => api.post('/api/products', product),
  updateProduct: (id, product) => api.put(`/api/products/${id}`, product),
  deleteProduct: (id) => api.delete(`/api/products/${id}`),
};

export const orderAPI = {
  placeOrder: (orderData) => {
    const username = localStorage.getItem('username');
    if (!username) {
      throw new Error('User not authenticated');
    }
    return api.post('/api/orders', orderData, {
      headers: {
        'X-Username': username,
        'Content-Type': 'application/json'
      }
    });
  },
  confirmOrder: (orderId) => api.post(`/api/orders/${orderId}/confirm`),
  getUserOrders: () => {
    const username = localStorage.getItem('username');
    return api.get(`/api/orders/getUserOrders?username=${username}`);
  },
  getOrderAmount: (orderId) => api.get(`/api/orders/${orderId}/amount`),
  updateOrderStatus: (orderId, status) => api.put(`/api/orders/${orderId}/status?status=${status}`),
};

export const cartAPI = {
  getCart: (username) => api.get(`/api/cart/${username}`),
  addItem: (username, item) => api.post(`/api/cart/${username}/items`, item, {
    headers: {
      'Content-Type': 'application/json'
    }
  }),
  updateItem: (username, productId, qty) => api.put(`/api/cart/${username}/items/${productId}?qty=${qty}`),
  clearCart: (username) => api.delete(`/api/cart/internal/${username}`),
};

export const paymentAPI = {
  createPayment: (orderId) => api.post('/api/payments/create', { orderId }),
  verifyPayment: (verifyData) => api.post('/api/payments/verify', verifyData),
  validatePaymentMethod: (orderId, paymentMethod, amount) => 
    api.post('/api/payments/validate', { orderId, paymentMethod, amount }),
};

export const recommendationAPI = {
  getRecommendations: (userId) => api.get(`/api/recommendations/${userId}`),
};

export default api;