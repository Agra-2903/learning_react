# E-Commerce Frontend

A modern React frontend for the SmartStore e-commerce platform built with Vite and Tailwind CSS.

## Features

- **User Authentication**: Login and registration with JWT tokens
- **Product Catalog**: Browse products with search and category filtering
- **Shopping Cart**: Add/remove products and manage quantities
- **Order Management**: Place orders and view order history
- **Admin Dashboard**: Product management for administrators
- **Responsive Design**: Mobile-friendly interface with Tailwind CSS

## Tech Stack

- **React 18** - Frontend framework
- **Vite** - Build tool and dev server
- **React Router** - Client-side routing
- **Axios** - HTTP client for API calls
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Icon library

## Getting Started

### Prerequisites

- Node.js 16+ and npm
- Backend services running on:
  - API Gateway: http://localhost:8080
  - Auth Service: http://localhost:8081
  - Product Service: http://localhost:8082
  - Order Service: http://localhost:8083

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

3. Open http://localhost:3000 in your browser

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── Navbar.jsx      # Navigation bar
│   ├── ProductCard.jsx # Product display card
│   └── ProtectedRoute.jsx # Route protection
├── context/            # React Context providers
│   ├── AuthContext.jsx # Authentication state
│   └── CartContext.jsx # Shopping cart state
├── pages/              # Page components
│   ├── Home.jsx        # Landing page
│   ├── Login.jsx       # User login
│   ├── Register.jsx    # User registration
│   ├── Products.jsx    # Product catalog
│   ├── Cart.jsx        # Shopping cart
│   ├── Orders.jsx      # Order history
│   └── Admin.jsx       # Admin dashboard
├── services/           # API service layer
│   └── api.js          # HTTP client and API calls
├── App.jsx             # Main application component
└── main.jsx            # Application entry point
```

## API Integration

The frontend integrates with the following backend services:

- **Authentication**: `/api/auth/login`, `/api/auth/register`
- **Products**: `/api/products` (CRUD operations)
- **Orders**: `/api/orders` (create and retrieve)
- **Recommendations**: `/api/recommendations/{userId}`

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## Environment Configuration

Update the API base URL in `src/services/api.js` if your backend runs on different ports:

```javascript
const API_BASE_URL = 'http://localhost:8080'; // API Gateway URL
```

## User Roles

- **Regular Users**: Browse products, manage cart, place orders
- **Administrators**: All user features plus product management

To register as admin, use the admin secret key during registration.