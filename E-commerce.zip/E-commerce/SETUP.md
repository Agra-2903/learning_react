# E-Commerce Application - Complete Setup

## Backend Services

### Service Ports
- **API Gateway**: 8080 (Main entry point)
- **Auth Service**: 8081 (Authentication & Authorization)
- **Order Service**: 8082 (Order Management)
- **Product Service**: 8083 (Product Catalog)
- **Cart Service**: 8084 (Shopping Cart)
- **Notification Service**: 8085 (Email Notifications)
- **Payment Service**: 8086 (Payment Processing with Razorpay)

### Frontend
- **Port**: 3000 (React Vite Application)

## Quick Start

### 1. Start All Backend Services
```bash
start-backend-simple.bat
```
This will start all 7 services in sequence with proper timing.

### 2. Verify Services
```bash
check-services.bat
```
Wait 2-3 minutes after starting, then verify all services are running.

### 3. Start Frontend
```bash
cd e-commerce-frontend
npm run dev
```

## Features

### User Features
- User Registration & Login (JWT Authentication)
- Browse Products with Search & Filters
- Add Products to Cart
- Place Orders with Shipping Address
- View Order History
- Payment Integration (Razorpay)

### Admin Features
- Product Management (CRUD)
- View All Orders
- Update Order Status

## API Endpoints

### Authentication (`/api/auth`)
- POST `/register` - Register new user
- POST `/login` - User login

### Products (`/api/products`)
- GET `/` - Get all products (paginated)
- GET `/{id}` - Get product by ID
- POST `/` - Create product (Admin)
- PUT `/{id}` - Update product (Admin)
- DELETE `/{id}` - Delete product (Admin)

### Cart (`/api/cart`)
- GET `/{username}` - Get user cart
- POST `/{username}/items` - Add item to cart
- PUT `/{username}/items/{productId}` - Update cart item
- DELETE `/internal/{username}` - Clear cart

### Orders (`/api/orders`)
- POST `/` - Place order (requires X-Username header)
- GET `/getUserOrders?username={username}` - Get user orders
- PUT `/{orderId}/status` - Update order status

### Payments (`/api/payments`)
- POST `/create` - Create payment order
- POST `/verify` - Verify payment
- POST `/validate` - Validate payment method

## Troubleshooting

### Services Not Starting
- Ensure Java 17+ is installed
- Ensure Maven is installed
- Check if ports 8080-8086 are free
- Ensure MySQL is running on port 3306

### Connection Issues
- Verify all services are running with `check-services.bat`
- Check service logs in terminal windows
- Restart services if needed

### Database Issues
- Ensure MySQL is running
- Check credentials in application.properties files
- Default: username=test, password=7803

## Technology Stack

### Backend
- Spring Boot 3.x
- Spring Cloud Gateway
- Spring Security with JWT
- MySQL Database
- Kafka (for notifications)
- Razorpay (for payments)

### Frontend
- React 18
- Vite
- React Router
- Axios
- Simple CSS

## Development

### Adding New Features
1. Update backend service
2. Add route to API Gateway if needed
3. Update frontend API service
4. Create/update React components

### Environment Variables
Update in respective `application.properties` files:
- Database credentials
- JWT secret
- Razorpay API keys
- Kafka configuration