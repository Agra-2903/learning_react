package com.smartstore.auth_service.model;

public enum Role {
    ADMIN,
    USER
}
