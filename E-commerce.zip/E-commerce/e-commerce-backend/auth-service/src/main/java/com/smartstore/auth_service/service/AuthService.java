package com.smartstore.auth_service.service;

import com.smartstore.auth_service.model.Role;
import com.smartstore.auth_service.security.JwtUtil;
import com.smartstore.auth_service.dto.JwtResponse;
import com.smartstore.auth_service.dto.LoginRequest;
import com.smartstore.auth_service.dto.RegisterRequest;
import com.smartstore.auth_service.model.User;
import com.smartstore.auth_service.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private JwtUtil jwtUtil;
    
    @Value("${admin.secret}")
    private String adminSecret;
    
    public String register(RegisterRequest request) {
        
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new RuntimeException("Username is already taken!");
        }
        
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email is already in use!");
        }
        
        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        
        if (request.getAdminSecret() != null && adminSecret.equals(request.getAdminSecret())) {
            user.setRole(Role.ADMIN);
        } else {
            user.setRole(Role.USER);
        }
        
        userRepository.save(user);
        return "User registered successfully!";
    }
    
    public JwtResponse login(LoginRequest request) {
        if (request.getUsername() == null || request.getUsername().trim().isEmpty()) {
            throw new RuntimeException("Username is required");
        }
        if (request.getPassword() == null || request.getPassword().trim().isEmpty()) {
            throw new RuntimeException("Password is required");
        }

        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        // Generate JWT
        String token = jwtUtil.generateToken(user.getUsername(), user.getRole().name());

        // Return JwtResponse directly
        return new JwtResponse(token, user.getUsername(), user.getRole().name());

    }

    public String getUserEmailByUsername(String username) {
        return userRepository.findByUsername(username)
                .map(User::getEmail)
                .orElseThrow(() -> new RuntimeException("User not found with username: " + username));
    }
}