package com.smartstore.product_service.service;

import com.smartstore.product_service.dto.CreateProductDTO;
import com.smartstore.product_service.dto.ProductDTO;
import com.smartstore.product_service.model.Product;
import com.smartstore.product_service.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private ProductService productService;

    private Product testProduct;
    private ProductDTO testProductDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        testProduct = new Product();
        testProduct.setId(1L);
        testProduct.setName("Laptop");
        testProduct.setDescription("High-performance laptop");
        testProduct.setPrice(new BigDecimal("999.99"));
        testProduct.setStock(10);
        testProduct.setCategory("Electronics");
        testProduct.setImageUrl("http://example.com/laptop.jpg");

        testProductDTO = new ProductDTO();
        testProductDTO.setId(1L);
        testProductDTO.setName("Laptop");
        testProductDTO.setDescription("High-performance laptop");
        testProductDTO.setPrice(new BigDecimal("999.99"));
        testProductDTO.setStock(10);
    }

    // ==================== List Products Tests ====================
    @Test
    void testListProductsSuccessfully() {
        // Arrange
        Pageable pageable = PageRequest.of(0, 10);
        List<Product> products = new ArrayList<>();
        products.add(testProduct);

        Product product2 = new Product();
        product2.setId(2L);
        product2.setName("Mouse");
        products.add(product2);

        Page<Product> expectedPage = new PageImpl<>(products, pageable, 2);
        when(productRepository.findAll(pageable)).thenReturn(expectedPage);

        // Act
        Page<Product> result = productService.list(pageable);

        // Assert
        assertEquals(2, result.getContent().size());
        assertEquals("Laptop", result.getContent().get(0).getName());
        assertEquals("Mouse", result.getContent().get(1).getName());
        verify(productRepository, times(1)).findAll(pageable);
    }

    @Test
    void testListProductsEmpty() {
        // Arrange
        Pageable pageable = PageRequest.of(0, 10);
        Page<Product> emptyPage = new PageImpl<>(new ArrayList<>(), pageable, 0);
        when(productRepository.findAll(pageable)).thenReturn(emptyPage);

        // Act
        Page<Product> result = productService.list(pageable);

        // Assert
        assertTrue(result.isEmpty());
        verify(productRepository, times(1)).findAll(pageable);
    }

    // ==================== Get Product By ID Tests ====================
    @Test
    void testGetProductDTOByIdSuccessfully() {
        // Arrange
        Long productId = 1L;
        when(productRepository.findById(productId)).thenReturn(Optional.of(testProduct));

        // Act
        ProductDTO result = productService.getProductDTOById(productId);

        // Assert
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Laptop", result.getName());
        assertEquals(new BigDecimal("999.99"), result.getPrice());
        assertEquals(10, result.getStock());
        assertEquals("High-performance laptop", result.getDescription());
        verify(productRepository, times(1)).findById(productId);
    }

    @Test
    void testGetProductDTOByIdNotFound() {
        // Arrange
        Long productId = 999L;
        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                productService.getProductDTOById(productId)
        );
        assertEquals("Product not found", exception.getMessage());
        verify(productRepository, times(1)).findById(productId);
    }

    @Test
    void testGetProductByIdSuccessfully() {
        // Arrange
        Long productId = 1L;
        when(productRepository.findById(productId)).thenReturn(Optional.of(testProduct));

        // Act
        Product result = productService.getProductById(productId);

        // Assert
        assertNotNull(result);
        assertEquals(testProduct.getId(), result.getId());
        assertEquals(testProduct.getName(), result.getName());
        verify(productRepository, times(1)).findById(productId);
    }

    @Test
    void testGetProductByIdNotFound() {
        // Arrange
        Long productId = 999L;
        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                productService.getProductById(productId)
        );
        assertEquals("Product not found", exception.getMessage());
    }

    // ==================== Get Product By Name Tests ====================
    @Test
    void testGetProductByNameSuccessfully() {
        // Arrange
        String productName = "Laptop";
        when(productRepository.findByName(productName)).thenReturn(Optional.of(testProduct));

        // Act
        ProductDTO result = productService.getProductByName(productName);

        // Assert
        assertNotNull(result);
        assertEquals("Laptop", result.getName());
        assertEquals(new BigDecimal("999.99"), result.getPrice());
        verify(productRepository, times(1)).findByName(productName);
    }

    @Test
    void testGetProductByNameNotFound() {
        // Arrange
        String productName = "NonExistentProduct";
        when(productRepository.findByName(productName)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                productService.getProductByName(productName)
        );
        assertEquals("Product not found: " + productName, exception.getMessage());
    }

    // ==================== Create Product Tests ====================
    @Test
    void testCreateProductSuccessfully() {
        // Arrange
        CreateProductDTO dto = new CreateProductDTO();
        dto.setName("Keyboard");
        dto.setDescription("Mechanical keyboard");
        dto.setPrice(new BigDecimal("149.99"));
        dto.setStock(50);
        dto.setCategory("Electronics");
        dto.setImageUrl("http://example.com/keyboard.jpg");

        when(productRepository.findByName("Keyboard")).thenReturn(Optional.empty());
        when(productRepository.save(any(Product.class))).thenAnswer(invocation -> {
            Product product = invocation.getArgument(0);
            product.setId(2L);
            return product;
        });

        // Act
        Product result = productService.createProduct(dto);

        // Assert
        assertNotNull(result);
        assertEquals("Keyboard", result.getName());
        assertEquals(new BigDecimal("149.99"), result.getPrice());
        assertEquals(50, result.getStock());
        verify(productRepository, times(1)).findByName("Keyboard");
        verify(productRepository, times(1)).save(any(Product.class));
    }

    @Test
    void testCreateProductWithDuplicateName() {
        // Arrange
        CreateProductDTO dto = new CreateProductDTO();
        dto.setName("Laptop");
        dto.setDescription("Another laptop");
        dto.setPrice(new BigDecimal("899.99"));
        dto.setStock(5);
        dto.setCategory("Electronics");
        dto.setImageUrl("http://example.com/laptop2.jpg");

        when(productRepository.findByName("Laptop")).thenReturn(Optional.of(testProduct));

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
                productService.createProduct(dto)
        );
        assertEquals("Product with name 'Laptop' already exists", exception.getMessage());
        verify(productRepository, never()).save(any());
    }

    // ==================== Update Product Tests ====================
    @Test
    void testUpdateProductSuccessfully() {
        // Arrange
        Long productId = 1L;
        Product updatedDetails = new Product();
        updatedDetails.setName("Updated Laptop");
        updatedDetails.setDescription("Updated description");
        updatedDetails.setPrice(new BigDecimal("1099.99"));
        updatedDetails.setStock(15);
        updatedDetails.setCategory("Electronics");
        updatedDetails.setImageUrl("http://example.com/updated-laptop.jpg");

        when(productRepository.findById(productId)).thenReturn(Optional.of(testProduct));
        when(productRepository.save(any(Product.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Product result = productService.updateProduct(productId, updatedDetails);

        // Assert
        assertEquals("Updated Laptop", result.getName());
        assertEquals(new BigDecimal("1099.99"), result.getPrice());
        assertEquals(15, result.getStock());
        verify(productRepository, times(1)).findById(productId);
        verify(productRepository, times(1)).save(any(Product.class));
    }

    @Test
    void testUpdateProductNotFound() {
        // Arrange
        Long productId = 999L;
        Product updatedDetails = new Product();
        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                productService.updateProduct(productId, updatedDetails)
        );
        assertEquals("Product not found", exception.getMessage());
        verify(productRepository, never()).save(any());
    }

    // ==================== Delete Product Tests ====================
    @Test
    void testDeleteProductSuccessfully() {
        // Arrange
        Long productId = 1L;

        // Act
        productService.deleteProduct(productId);

        // Assert
        verify(productRepository, times(1)).deleteById(productId);
    }

    // ==================== Reduce Stock Tests ====================
    @Test
    void testReduceStockSuccessfully() {
        // Arrange
        String productName = "Laptop";
        int quantity = 5;
        when(productRepository.reduceStockIfAvailable(productName, quantity)).thenReturn(1);

        // Act
        boolean result = productService.reduceStock(productName, quantity);

        // Assert
        assertTrue(result);
        verify(productRepository, times(1)).reduceStockIfAvailable(productName, quantity);
    }

    @Test
    void testReduceStockFailed() {
        // Arrange
        String productName = "Laptop";
        int quantity = 100;
        when(productRepository.reduceStockIfAvailable(productName, quantity)).thenReturn(0);

        // Act
        boolean result = productService.reduceStock(productName, quantity);

        // Assert
        assertFalse(result);
        verify(productRepository, times(1)).reduceStockIfAvailable(productName, quantity);
    }

    // ==================== Increase Stock Tests ====================
    @Test
    void testIncreaseStockSuccessfully() {
        // Arrange
        String productName = "Laptop";
        int quantity = 5;
        when(productRepository.increaseStock(productName, quantity)).thenReturn(1);

        // Act
        boolean result = productService.increaseStock(productName, quantity);

        // Assert
        assertTrue(result);
        verify(productRepository, times(1)).increaseStock(productName, quantity);
    }

    @Test
    void testIncreaseStockFailed() {
        // Arrange
        String productName = "NonExistent";
        int quantity = 5;
        when(productRepository.increaseStock(productName, quantity)).thenReturn(0);

        // Act
        boolean result = productService.increaseStock(productName, quantity);

        // Assert
        assertFalse(result);
    }
}

