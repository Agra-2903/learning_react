package com.smartstore.product_service.service;

import com.smartstore.product_service.dto.CreateProductDTO;
import com.smartstore.product_service.dto.ProductDTO;
import com.smartstore.product_service.model.Product;
import com.smartstore.product_service.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    
    @Autowired
    private ProductRepository productRepository;

    public Page<Product> list(Pageable pageable) {
        return productRepository.findAll(pageable);
    }
    
    public ProductDTO getProductDTOById(Long id) {

        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // Create DTO using getters
        ProductDTO dto = new ProductDTO();
        dto.setId(product.getId());
        dto.setName(product.getName());
        dto.setPrice(product.getPrice());
        dto.setStock(product.getStock());
        dto.setDescription(product.getDescription());

        return dto;

    }

    public Product getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    public ProductDTO getProductByName(String name) {
        Product product = productRepository.findByName(name)
                .orElseThrow(() -> new RuntimeException("Product not found: " + name));

        ProductDTO dto = new ProductDTO();
        dto.setId(product.getId());
        dto.setName(product.getName());
        dto.setPrice(product.getPrice());
        dto.setStock(product.getStock());
        dto.setDescription(product.getDescription());
        return dto;
    }

    public Product createProduct(CreateProductDTO dto) {
        Optional<Product> existingProduct = productRepository.findByName(dto.getName());
        if (existingProduct.isPresent()) {
            throw new IllegalArgumentException("Product with name '" + dto.getName() + "' already exists");
        }

        Product product = new Product();
        product.setName(dto.getName());
        product.setDescription(dto.getDescription());
        product.setCategory(dto.getCategory());
        product.setImageUrl(dto.getImageUrl());
        product.setPrice(dto.getPrice());
        product.setStock(dto.getStock());
        return productRepository.save(product);
    }
    
    public Product updateProduct(Long id, Product productDetails) {
        Product product = getProductById(id);
        product.setName(productDetails.getName());
        product.setDescription(productDetails.getDescription());
        product.setPrice(productDetails.getPrice());
        product.setCategory(productDetails.getCategory());
        product.setImageUrl(productDetails.getImageUrl());
        product.setStock(productDetails.getStock());
        return productRepository.save(product);
    }
    
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

    public boolean reduceStock(String productName, int qty) {
        int changed = productRepository.reduceStockIfAvailable(productName, qty);
        return changed == 1;
    }

    public boolean increaseStock(String productName, int qty) {
        int changed = productRepository.increaseStock(productName, qty);
        return changed == 1;
    }
}