package com.smartstore.product_service.controller;

//import com.smartstore.product_service.model.Product;
import com.smartstore.product_service.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {
    
    @Autowired
    private ProductService productService;
    
    @PatchMapping("/{productName}/adjust")
    public ResponseEntity<Void> adjustStock(@PathVariable String productName, @RequestParam Integer stockChange) {
        productService.increaseStock(productName, stockChange);
        return ResponseEntity.ok().build();
    }
}