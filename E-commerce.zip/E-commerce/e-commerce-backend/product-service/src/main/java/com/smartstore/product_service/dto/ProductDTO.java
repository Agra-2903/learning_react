package com.smartstore.product_service.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductDTO {
    @NotNull(message = "Product ID cannot be null")
    @Positive(message = "Product ID must be greater than zero")
    private Long id;

    @NotBlank(message = "Product name cannot be blank")
    @Size(min = 1, max = 500, message = "Product name must be between 1 and 500 characters")
    private String name;

    @NotNull(message = "Price cannot be null")
    @DecimalMin(value = "0.01", message = "Price must be at least 0.01")
    @DecimalMax(value = "9999999.99", message = "Price cannot exceed 9999999.99")
    private BigDecimal price;

    @NotNull(message = "Stock cannot be null")
    @Min(value = 0, message = "Stock cannot be negative")
    @Max(value = 1000000, message = "Stock cannot exceed 1000000")
    private Integer stock;

    @Size(max = 2000, message = "Description cannot exceed 2000 characters")
    private String description;
}

