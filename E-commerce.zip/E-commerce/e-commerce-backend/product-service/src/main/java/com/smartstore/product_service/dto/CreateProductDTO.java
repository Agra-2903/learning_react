package com.smartstore.product_service.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreateProductDTO {
    @NotBlank @Size(max = 200)
    private String name;

    @Size(max = 2000)
    private String description;

    @NotBlank
    private String category;

    @NotBlank
    @Pattern(regexp = "^(https?|ftp)://[^\\s/$.?#].[^\\s]*$", message = "must be a valid URL")
    private String imageUrl;

    @NotNull @DecimalMin(value = "0.0", inclusive = false)
    private BigDecimal price;

    @NotNull @Min(0)
    private Integer stock;
}
