package com.smartstore.product_service.repository;

import com.smartstore.product_service.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByCategory(String category);

    Optional<Product> findByName(String name);
    
    @Query("SELECT p FROM Product p WHERE p.stock > 0 ORDER BY p.id DESC")
    List<Product> findAvailableProducts();

    @Modifying
    @Transactional
    @Query("UPDATE Product p SET p.stock = p.stock - :qty WHERE p.name = :name AND p.stock >= :qty")
    int reduceStockIfAvailable(@Param("name") String name, @Param("qty") int qty);

    @Modifying
    @Transactional
    @Query("UPDATE Product p SET p.stock = p.stock + :qty WHERE p.name = :name")
    int increaseStock(@Param("name") String name, @Param("qty") int qty);
}