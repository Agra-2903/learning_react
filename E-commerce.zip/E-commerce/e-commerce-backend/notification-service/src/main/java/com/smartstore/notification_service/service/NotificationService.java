package com.smartstore.notification_service.service;

import com.smartstore.notification_service.event.OrderConfirmedEvent;
import com.smartstore.notification_service.event.OutForDeliveryEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Slf4j
@Service
public class NotificationService {

    @Autowired
    private EmailService emailService;

    public void handleOrderConfirmed(OrderConfirmedEvent event) {
        log.info("Processing order confirmed notification for Order ID: {}", event.getOrderId());

        String orderItems = buildOrderItemsString(event);
        String totalAmount = event.getTotalAmount() != null ? event.getTotalAmount().toString() : "0.00";

        emailService.sendOrderConfirmationEmail(
                event.getUserEmail(),
                event.getOrderId(),
                event.getUsername(),
                event.getShippingAddress(),
                totalAmount,
                orderItems
        );

        log.info("Order confirmed notification processed for Order ID: {}", event.getOrderId());
    }

    public void handleOutForDelivery(OutForDeliveryEvent event) {
        log.info("Processing out for delivery notification for Order ID: {}", event.getOrderId());

        emailService.sendOutForDeliveryEmail(
                event.getUserEmail(),
                event.getOrderId(),
                event.getUsername(),
                event.getShippingAddress()
        );

        log.info("Out for delivery notification processed for Order ID: {}", event.getOrderId());
    }

    private String buildOrderItemsString(OrderConfirmedEvent event) {
        if (event.getOrderItems() == null || event.getOrderItems().isEmpty()) {
            return "No items";
        }

        return event.getOrderItems().stream()
                .map(item -> String.format(
                        "%s (Qty: %d) - $%.2f",
                        item.getProductName(),
                        item.getQuantity(),
                        item.getPrice()
                ))
                .collect(Collectors.joining("<br>"));
    }
}

