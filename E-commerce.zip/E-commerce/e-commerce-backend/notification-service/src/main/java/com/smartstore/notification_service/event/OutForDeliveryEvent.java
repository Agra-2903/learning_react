package com.smartstore.notification_service.event;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OutForDeliveryEvent implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("orderId")
    private Long orderId;

    @JsonProperty("username")
    private String username;

    @JsonProperty("userEmail")
    private String userEmail;

    @JsonProperty("shippingAddress")
    private String shippingAddress;

    @JsonProperty("timestamp")
    private LocalDateTime timestamp;
}

