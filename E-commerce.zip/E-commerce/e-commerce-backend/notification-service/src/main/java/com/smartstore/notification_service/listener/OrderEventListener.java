package com.smartstore.notification_service.listener;

import com.smartstore.notification_service.event.OrderConfirmedEvent;
import com.smartstore.notification_service.event.OutForDeliveryEvent;
import com.smartstore.notification_service.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class OrderEventListener {

    @Autowired
    private NotificationService notificationService;

    @KafkaListener(
            topics = "order-confirmed",
            groupId = "notification-service-group",
            containerFactory = "orderConfirmedListenerContainerFactory"
    )
    public void handleOrderConfirmedEvent(OrderConfirmedEvent event) {
        log.info("Received order confirmed event for Order ID: {}", event.getOrderId());
        try {
            notificationService.handleOrderConfirmed(event);
        } catch (Exception e) {
            log.error("Error processing order confirmed event for Order ID: {}", event.getOrderId(), e);
        }
    }

    @KafkaListener(
            topics = "order-out-for-delivery",
            groupId = "notification-service-group",
            containerFactory = "outForDeliveryListenerContainerFactory"
    )
    public void handleOutForDeliveryEvent(OutForDeliveryEvent event) {
        log.info("Received out for delivery event for Order ID: {}", event.getOrderId());
        try {
            notificationService.handleOutForDelivery(event);
        } catch (Exception e) {
            log.error("Error processing out for delivery event for Order ID: {}", event.getOrderId(), e);
        }
    }
}

