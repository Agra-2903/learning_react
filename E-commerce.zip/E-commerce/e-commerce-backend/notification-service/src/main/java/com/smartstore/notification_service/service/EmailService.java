package com.smartstore.notification_service.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Slf4j
@Service
public class EmailService {

    @Autowired(required = false)
    private JavaMailSender mailSender;

    public void sendOrderConfirmationEmail(String recipientEmail, Long orderId, String username,
                                          String shippingAddress, String totalAmount, String orderItems) {
        try {
            if (mailSender == null) {
                log.warn("JavaMailSender is not configured. Skipping email for order: {}", orderId);
                return;
            }

            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setTo(recipientEmail);
            helper.setSubject("Order Confirmation - Order #" + orderId);

            String htmlContent = buildOrderConfirmationEmailHtml(orderId, username, shippingAddress, totalAmount, orderItems);
            helper.setText(htmlContent, true);

            mailSender.send(message);
            log.info("Order confirmation email sent to: {} for Order ID: {}", recipientEmail, orderId);
        } catch (MessagingException e) {
            log.error("Failed to send order confirmation email to: {} for Order ID: {}", recipientEmail, orderId, e);
        } catch (Exception e) {
            log.error("Unexpected error while sending order confirmation email", e);
        }
    }

    public void sendOutForDeliveryEmail(String recipientEmail, Long orderId, String username, String shippingAddress) {
        try {
            if (mailSender == null) {
                log.warn("JavaMailSender is not configured. Skipping email for order: {}", orderId);
                return;
            }

            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setTo(recipientEmail);
            helper.setSubject("Order Out For Delivery - Order #" + orderId);

            String htmlContent = buildOutForDeliveryEmailHtml(orderId, username, shippingAddress);
            helper.setText(htmlContent, true);

            mailSender.send(message);
            log.info("Out for delivery email sent to: {} for Order ID: {}", recipientEmail, orderId);
        } catch (MessagingException e) {
            log.error("Failed to send out for delivery email to: {} for Order ID: {}", recipientEmail, orderId, e);
        } catch (Exception e) {
            log.error("Unexpected error while sending out for delivery email", e);
        }
    }

    private String buildOrderConfirmationEmailHtml(Long orderId, String username, String shippingAddress,
                                                    String totalAmount, String orderItems) {
        return "<!DOCTYPE html>" +
                "<html>" +
                "<head>" +
                "<style>" +
                "body { font-family: Arial, sans-serif; }" +
                ".container { max-width: 600px; margin: 0 auto; padding: 20px; }" +
                ".header { background-color: #007bff; color: white; padding: 20px; text-align: center; border-radius: 5px; }" +
                ".content { margin-top: 20px; }" +
                ".order-detail { background-color: #f8f9fa; padding: 15px; margin: 10px 0; border-radius: 5px; }" +
                ".footer { margin-top: 30px; text-align: center; color: #666; font-size: 12px; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "<div class='container'>" +
                "<div class='header'>" +
                "<h1>Order Confirmed!</h1>" +
                "</div>" +
                "<div class='content'>" +
                "<p>Dear " + username + ",</p>" +
                "<p>Thank you for your order! Your order has been confirmed and will be processed soon.</p>" +
                "<div class='order-detail'>" +
                "<h3>Order Details</h3>" +
                "<p><strong>Order ID:</strong> " + orderId + "</p>" +
                "<p><strong>Total Amount:</strong> $" + totalAmount + "</p>" +
                "<p><strong>Shipping Address:</strong> " + shippingAddress + "</p>" +
                "<p><strong>Items:</strong></p>" +
                "<p>" + orderItems + "</p>" +
                "</div>" +
                "<p>You will receive a notification once your order is out for delivery.</p>" +
                "</div>" +
                "<div class='footer'>" +
                "<p>Thank you for shopping with us!</p>" +
                "<p>SmartStore - Your trusted online shopping destination</p>" +
                "</div>" +
                "</div>" +
                "</body>" +
                "</html>";
    }

    private String buildOutForDeliveryEmailHtml(Long orderId, String username, String shippingAddress) {
        return "<!DOCTYPE html>" +
                "<html>" +
                "<head>" +
                "<style>" +
                "body { font-family: Arial, sans-serif; }" +
                ".container { max-width: 600px; margin: 0 auto; padding: 20px; }" +
                ".header { background-color: #28a745; color: white; padding: 20px; text-align: center; border-radius: 5px; }" +
                ".content { margin-top: 20px; }" +
                ".order-detail { background-color: #f8f9fa; padding: 15px; margin: 10px 0; border-radius: 5px; }" +
                ".footer { margin-top: 30px; text-align: center; color: #666; font-size: 12px; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "<div class='container'>" +
                "<div class='header'>" +
                "<h1>Order Out For Delivery!</h1>" +
                "</div>" +
                "<div class='content'>" +
                "<p>Dear " + username + ",</p>" +
                "<p>Great news! Your order is out for delivery today.</p>" +
                "<div class='order-detail'>" +
                "<h3>Delivery Details</h3>" +
                "<p><strong>Order ID:</strong> " + orderId + "</p>" +
                "<p><strong>Delivery Address:</strong> " + shippingAddress + "</p>" +
                "<p>Please ensure someone is available to receive the package.</p>" +
                "</div>" +
                "<p>We appreciate your business!</p>" +
                "</div>" +
                "<div class='footer'>" +
                "<p>SmartStore - Your trusted online shopping destination</p>" +
                "</div>" +
                "</div>" +
                "</body>" +
                "</html>";
    }
}

