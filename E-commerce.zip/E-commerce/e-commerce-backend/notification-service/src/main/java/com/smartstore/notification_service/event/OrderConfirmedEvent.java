package com.smartstore.notification_service.event;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderConfirmedEvent implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("orderId")
    private Long orderId;

    @JsonProperty("username")
    private String username;

    @JsonProperty("userEmail")
    private String userEmail;

    @JsonProperty("shippingAddress")
    private String shippingAddress;

    @JsonProperty("totalAmount")
    private BigDecimal totalAmount;

    @JsonProperty("orderDate")
    private LocalDateTime orderDate;

    @JsonProperty("orderItems")
    private List<OrderItemDetail> orderItems;

    @JsonProperty("timestamp")
    private LocalDateTime timestamp;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OrderItemDetail implements Serializable {
        private static final long serialVersionUID = 1L;

        @JsonProperty("productName")
        private String productName;

        @JsonProperty("quantity")
        private Integer quantity;

        @JsonProperty("price")
        private BigDecimal price;
    }
}

