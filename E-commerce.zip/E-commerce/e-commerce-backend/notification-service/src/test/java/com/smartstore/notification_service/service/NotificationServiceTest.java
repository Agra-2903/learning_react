package com.smartstore.notification_service.service;

import com.smartstore.notification_service.event.OrderConfirmedEvent;
import com.smartstore.notification_service.event.OutForDeliveryEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class NotificationServiceTest {

    @Mock
    private EmailService emailService;

    @InjectMocks
    private NotificationService notificationService;

    private OrderConfirmedEvent orderConfirmedEvent;
    private OutForDeliveryEvent outForDeliveryEvent;

    @BeforeEach
    void setUp() {
        orderConfirmedEvent = new OrderConfirmedEvent();
        orderConfirmedEvent.setOrderId(1L);
        orderConfirmedEvent.setUsername("testuser");
        orderConfirmedEvent.setUserEmail("test@example.com");
        orderConfirmedEvent.setShippingAddress("123 Main St, City, State");
        orderConfirmedEvent.setTotalAmount(BigDecimal.valueOf(99.99));
        orderConfirmedEvent.setOrderDate(LocalDateTime.now());

        List<OrderConfirmedEvent.OrderItemDetail> items = new ArrayList<>();
        items.add(new OrderConfirmedEvent.OrderItemDetail("Product1", 2, BigDecimal.valueOf(49.99)));
        items.add(new OrderConfirmedEvent.OrderItemDetail("Product2", 1, BigDecimal.valueOf(30.00)));
        orderConfirmedEvent.setOrderItems(items);

        outForDeliveryEvent = new OutForDeliveryEvent();
        outForDeliveryEvent.setOrderId(1L);
        outForDeliveryEvent.setUsername("testuser");
        outForDeliveryEvent.setUserEmail("test@example.com");
        outForDeliveryEvent.setShippingAddress("123 Main St, City, State");
    }

    @Test
    void testHandleOrderConfirmed_Success() {
        notificationService.handleOrderConfirmed(orderConfirmedEvent);

        verify(emailService, times(1)).sendOrderConfirmationEmail(
                "test@example.com",
                1L,
                "testuser",
                "123 Main St, City, State",
                "99.99",
                contains("Product1")
        );
    }

    @Test
    void testHandleOrderConfirmed_WithEmptyOrderItems() {
        orderConfirmedEvent.setOrderItems(new ArrayList<>());

        notificationService.handleOrderConfirmed(orderConfirmedEvent);

        verify(emailService, times(1)).sendOrderConfirmationEmail(
                eq("test@example.com"),
                eq(1L),
                eq("testuser"),
                eq("123 Main St, City, State"),
                eq("99.99"),
                eq("No items")
        );
    }

    @Test
    void testHandleOrderConfirmed_WithNullTotalAmount() {
        orderConfirmedEvent.setTotalAmount(null);

        notificationService.handleOrderConfirmed(orderConfirmedEvent);

        verify(emailService, times(1)).sendOrderConfirmationEmail(
                eq("test@example.com"),
                eq(1L),
                eq("testuser"),
                eq("123 Main St, City, State"),
                eq("0.00"),
                anyString()
        );
    }

    @Test
    void testHandleOrderConfirmed_FormatOrderItems() {
        notificationService.handleOrderConfirmed(orderConfirmedEvent);

        verify(emailService, times(1)).sendOrderConfirmationEmail(
                anyString(),
                anyLong(),
                anyString(),
                anyString(),
                anyString(),
                argThat(content -> content.contains("Product1 (Qty: 2)") && content.contains("<br>"))
        );
    }

    @Test
    void testHandleOutForDelivery_Success() {
        notificationService.handleOutForDelivery(outForDeliveryEvent);

        verify(emailService, times(1)).sendOutForDeliveryEmail(
                "test@example.com",
                1L,
                "testuser",
                "123 Main St, City, State"
        );
    }

    @Test
    void testHandleOutForDelivery_CorrectParameters() {
        notificationService.handleOutForDelivery(outForDeliveryEvent);

        verify(emailService).sendOutForDeliveryEmail(
                eq("test@example.com"),
                eq(1L),
                eq("testuser"),
                eq("123 Main St, City, State")
        );
    }
}

