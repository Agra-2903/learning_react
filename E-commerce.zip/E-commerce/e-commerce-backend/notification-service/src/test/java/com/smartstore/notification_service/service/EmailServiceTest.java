package com.smartstore.notification_service.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmailServiceTest {

    @Mock
    private JavaMailSender mailSender;

    @Mock
    private MimeMessage mimeMessage;

    @InjectMocks
    private EmailService emailService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(emailService, "mailSender", mailSender);
    }

    @Test
    void testSendOrderConfirmationEmail_Success() throws MessagingException {
        when(mailSender.createMimeMessage()).thenReturn(mimeMessage);

        emailService.sendOrderConfirmationEmail(
                "customer@example.com",
                1L,
                "testuser",
                "123 Main St, City, State 12345",
                "99.99",
                "Product1 (Qty: 2) - $49.99"
        );

        verify(mailSender, times(1)).createMimeMessage();
        verify(mailSender, times(1)).send(mimeMessage);
    }

    @Test
    void testSendOrderConfirmationEmail_MailSenderNull() {
        ReflectionTestUtils.setField(emailService, "mailSender", null);

        emailService.sendOrderConfirmationEmail(
                "customer@example.com",
                1L,
                "testuser",
                "123 Main St",
                "99.99",
                "Product1"
        );

        // Should handle gracefully without throwing exception
    }

    @Test
    void testSendOrderConfirmationEmail_MessagingException() throws MessagingException {
        when(mailSender.createMimeMessage()).thenReturn(mimeMessage);
        doThrow(new MessagingException("Email send failed"))
                .when(mailSender).send(any(MimeMessage.class));

        emailService.sendOrderConfirmationEmail(
                "customer@example.com",
                1L,
                "testuser",
                "123 Main St",
                "99.99",
                "Product1"
        );

        // Should handle exception gracefully
        verify(mailSender, times(1)).send(mimeMessage);
    }

    @Test
    void testSendOutForDeliveryEmail_Success() throws MessagingException {
        when(mailSender.createMimeMessage()).thenReturn(mimeMessage);

        emailService.sendOutForDeliveryEmail(
                "customer@example.com",
                1L,
                "testuser",
                "123 Main St, City, State 12345"
        );

        verify(mailSender, times(1)).createMimeMessage();
        verify(mailSender, times(1)).send(mimeMessage);
    }

    @Test
    void testSendOutForDeliveryEmail_MailSenderNull() {
        ReflectionTestUtils.setField(emailService, "mailSender", null);

        emailService.sendOutForDeliveryEmail(
                "customer@example.com",
                1L,
                "testuser",
                "123 Main St"
        );

        // Should handle gracefully without throwing exception
    }

    @Test
    void testSendOutForDeliveryEmail_MessagingException() throws MessagingException {
        when(mailSender.createMimeMessage()).thenReturn(mimeMessage);
        doThrow(new MessagingException("Email send failed"))
                .when(mailSender).send(any(MimeMessage.class));

        emailService.sendOutForDeliveryEmail(
                "customer@example.com",
                1L,
                "testuser",
                "123 Main St"
        );

        verify(mailSender, times(1)).send(mimeMessage);
    }
}

