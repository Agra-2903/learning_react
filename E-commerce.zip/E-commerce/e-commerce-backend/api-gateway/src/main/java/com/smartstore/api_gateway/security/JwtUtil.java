package com.smartstore.api_gateway.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;

@Component
public class JwtUtil {

    private final SecretKey secretKey;

    public JwtUtil(@Value("${jwt.secret}") String secret) {
        this.secretKey = Keys.hmacShaKeyFor(secret.getBytes());
    }

    public Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(secretKey)
                .build()
                .parseSignedClaims(token)
                .getPayload();
//                .parseClaimsJws(token)
    }

    public String getUsername(String token) {
        return extractAllClaims(token).getSubject();
    }

    public String getRole(String token) {
        return extractAllClaims(token).get("role", String.class);
    }

    public boolean isTokenValid(String token) {
        try {
            Claims claims = extractAllClaims(token);

            Date now = new Date();

            Date expiration = claims.getExpiration();
            Date issuedAt = claims.getIssuedAt();

            System.out.println("JWT DEBUG -> subject=" + claims.getSubject() +
                    ", role=" + claims.get("role", String.class) +
                    ", issuedAt=" + issuedAt +
                    ", expiration=" + expiration +
                    ", now=" + now);

            if (expiration == null || expiration.before(now)) {
                return false;
            }

            if (issuedAt == null || issuedAt.after(now)) {
                return false;
            }
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }
}
//public class JwtUtil {
//
//    private final SecretKey secretKey;
//
//    public JwtUtil(@Value("${jwt.secret}") String secret) {
//        this.secretKey = Keys.hmacShaKeyFor(secret.getBytes());
//    }
//
//    public Claims extractClaims(String token) {
//        Jws<Claims> jws = Jwts.parser()
//                .verifyWith(secretKey)
//                .build()
//                .parseSignedClaims(token);
//        return jws.getPayload();
//    }
//
//    public String extractUsername(String token) {
//        return extractClaims(token).getSubject();
//    }
//
//    public String extractRole(String token) {
//        return extractClaims(token).get("role", String.class);
//    }
//}
