package com.smartstore.order_service.controller;

import com.smartstore.order_service.dto.CreateOrderDTO;
import com.smartstore.order_service.model.Order;
import com.smartstore.order_service.model.OrderStatus;
import com.smartstore.order_service.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    
    @Autowired
    private OrderService orderService;
    
    @PostMapping
    public ResponseEntity<?> placeOrder(
            @RequestHeader("X-Username") String username,
            @Valid @RequestBody CreateOrderDTO dto) {
        try {
            Map<String, Object> response = orderService.placeOrder(username, dto);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/{orderId}/confirm")
    public ResponseEntity<?> confirmOrder(@PathVariable Long orderId) {
        try {
            Order confirmedOrder = orderService.confirmOrder(orderId);
            return ResponseEntity.ok(confirmedOrder);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    
    @GetMapping("/getUserOrders")
    public ResponseEntity<List<Order>> getUserOrders(@RequestParam String username) {
        List<Order> orders = orderService.getUserOrders(username);
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/{orderId}/amount")
    public ResponseEntity<BigDecimal> getOrderAmount(@PathVariable Long orderId) {
        BigDecimal amount = orderService.getOrderAmount(orderId);
        return ResponseEntity.ok(amount);
    }

    @PutMapping("/{orderId}/status")
    public ResponseEntity<Order> updateOrderStatus(@PathVariable Long orderId, @RequestParam OrderStatus status) {
        Order updatedOrder = orderService.updateStatus(orderId, status);
        return ResponseEntity.ok(updatedOrder);
    }
}