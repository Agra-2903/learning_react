package com.smartstore.order_service.model;

public enum OrderStatus {
    PENDING, CONFIRMED, PROCESSING, SHIPPED, IN_TRANSIT, DELIVERED, CANCELLED
}
