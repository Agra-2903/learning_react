package com.smartstore.order_service.client;

import com.smartstore.order_service.dto.CartItemDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "cart-service", url = "http://localhost:8084")
public interface CartClient {
    @DeleteMapping("/api/cart/internal/{username}")
    ResponseEntity<Void> clearCart(@PathVariable("username") String username);

    @GetMapping("/api/cart/internal/{username}")
    List<CartItemDTO> getUserCart(@PathVariable("username") String username);
}
