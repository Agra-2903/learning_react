package com.smartstore.order_service.client;

import com.smartstore.order_service.dto.CreatePaymentRequest;
import com.smartstore.order_service.dto.CreatePaymentResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.math.BigDecimal;

@FeignClient(name = "payment-service", url = "http://localhost:8086")
public interface PaymentClient {

    @PostMapping("/api/payments/create")
    CreatePaymentResponse createPayment(@RequestBody CreatePaymentRequest request);
    
    @PostMapping("/api/payments/validate")
    boolean validatePaymentMethod(@RequestBody PaymentValidationRequest request);
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    class PaymentValidationRequest {
        private Long orderId;
        private String paymentMethod;
        private BigDecimal amount;
    }
}

