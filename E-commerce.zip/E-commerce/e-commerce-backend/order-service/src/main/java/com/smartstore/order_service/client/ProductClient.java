package com.smartstore.order_service.client;

import com.smartstore.order_service.dto.ProductDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "product-service", url = "http://localhost:8083")
public interface ProductClient {

    @GetMapping("/api/products/{id}")
    ProductDTO getProductDTOById(@PathVariable("id") Long id);

    @PutMapping("/api/products/internal/{productName}/decrement")
    ResponseEntity<Void> decrement(@PathVariable("productName") String productName, @RequestParam("qty") int qty);

    @PutMapping("/api/products/internal/{productName}/increment")
    ResponseEntity<Void> increment(@PathVariable("productName") String productName, @RequestParam("qty") int qty);

//    @GetMapping("/api/products/availability/{id}")
//    boolean checkProductAvailability(@PathVariable("id") Long id);
}
