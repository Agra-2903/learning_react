package com.smartstore.order_service.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConfirmPaymentDTO {
    @NotNull(message = "Order ID cannot be null")
    @Positive(message = "Order ID must be greater than zero")
    private Long orderId;

    @NotBlank(message = "Payment method is required")
    @Size(min = 3, max = 50, message = "Payment method must be between 3 and 50 characters")
    @Pattern(regexp = "^[A-Z_]+$", message = "Payment method must be uppercase letters and underscores only")
    private String paymentMethod;
}
