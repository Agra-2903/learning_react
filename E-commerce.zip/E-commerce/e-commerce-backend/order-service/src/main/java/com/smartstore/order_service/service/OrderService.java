package com.smartstore.order_service.service;

import com.smartstore.order_service.client.AuthClient;
import com.smartstore.order_service.client.CartClient;
import com.smartstore.order_service.client.PaymentClient;
import com.smartstore.order_service.client.ProductClient;
import com.smartstore.order_service.dto.CartItemDTO;
import com.smartstore.order_service.dto.CreateOrderDTO;
import com.smartstore.order_service.dto.CreatePaymentRequest;
import com.smartstore.order_service.dto.CreatePaymentResponse;
import com.smartstore.order_service.exception.OutOfStockException;
import com.smartstore.order_service.model.Order;
import com.smartstore.order_service.model.OrderItem;
import com.smartstore.order_service.model.OrderStatus;
import com.smartstore.order_service.repository.OrderRepository;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductClient productClient;

    @Autowired
    private CartClient cartClient;

    @Autowired
    private AuthClient authClient;

    @Autowired
    private PaymentClient paymentClient;


    @Transactional
    public Map<String, Object> placeOrder(String username, CreateOrderDTO dto) {
        List<String> decrementedProductNames = new ArrayList<>();
        Map<String, Integer> decrementedQty = new HashMap<>();

        try {
            // Fetch cart items for the user
            List<CartItemDTO> items = cartClient.getUserCart(username);

            if (items == null || items.isEmpty()) {
                throw new RuntimeException("Cart is empty. Cannot place order.");
            }

            // Validate stock and decrement product quantities
            for (CartItemDTO item : items) {
                try {
                    ResponseEntity<Void> resp = productClient.decrement(item.getProductName(), item.getQuantity());
                    if (!resp.getStatusCode().is2xxSuccessful()) {
                        throw new OutOfStockException("Product " + item.getProductName() + " is out of stock");
                    }
                    decrementedProductNames.add(item.getProductName());
                    decrementedQty.put(item.getProductName(), item.getQuantity());
                } catch (FeignException ex) {
                    log.error("Product decrement failed for {}: {}", item.getProductName(), ex.getMessage());
                    throw new OutOfStockException("Product " + item.getProductName() + " is out of stock or unavailable");
                }
            }

            // Create order in PENDING status
            log.info("Creating order for user: {}", username);
            Order order = new Order();
            order.setUsername(username);
            order.setShippingAddress(dto.getShippingAddress());
            order.setStatus(OrderStatus.PENDING);

            // Create order items and calculate total amount
            log.debug("Processing cart items for order");
            BigDecimal totalAmount = BigDecimal.ZERO;
            List<OrderItem> orderItems = new ArrayList<>();

            for (CartItemDTO cartItem : items) {
                OrderItem orderItem = new OrderItem();
                orderItem.setProductId(cartItem.getProductId());
                orderItem.setProductName(cartItem.getProductName());
                orderItem.setQuantity(cartItem.getQuantity());

                BigDecimal itemPrice = cartItem.getPrice();
                orderItem.setPrice(itemPrice);
                orderItem.setOrder(order);

                orderItems.add(orderItem);

                // Calculate total: price * quantity
                totalAmount = totalAmount.add(
                        itemPrice.multiply(BigDecimal.valueOf(cartItem.getQuantity()))
                );
            }

            order.setOrderItems(orderItems);
            order.setTotalAmount(totalAmount);

            // Save order in PENDING status
            log.info("Saving order in PENDING status with total amount: {}", totalAmount);
            Order savedOrder = orderRepository.save(order);

            // Initiate payment
            log.info("Initiating payment for order: {}", savedOrder.getId());
            CreatePaymentRequest paymentRequest = new CreatePaymentRequest();
            paymentRequest.setOrderId(savedOrder.getId());
            paymentRequest.setAmount(totalAmount);

            CreatePaymentResponse paymentResponse = null;
            try {
                paymentResponse = paymentClient.createPayment(paymentRequest);
                log.info("Payment initiated successfully for order: {}", savedOrder.getId());
            } catch (Exception ex) {
                log.error("Failed to create payment for order: {}", savedOrder.getId(), ex);
                throw new RuntimeException("Payment initiation failed: " + ex.getMessage(), ex);
            }

            // Return order and payment details
            Map<String, Object> response = new HashMap<>();
            response.put("order", savedOrder);
            response.put("payment", paymentResponse);

            return response;
        } catch (FeignException | OutOfStockException ex) {
            // Rollback: increment products back to inventory
            for (String pName : decrementedProductNames) {
                Integer q = decrementedQty.getOrDefault(pName, 1);
                try {
                    productClient.increment(pName, q);
                    log.info("Rolled back inventory for product: {}, quantity: {}", pName, q);
                } catch (Exception ignore) {
                    log.error("Failed to rollback inventory for product {}", pName);
                }
            }
            if (ex instanceof OutOfStockException) throw (OutOfStockException) ex;
            throw new RuntimeException("Order failed: " + ex.getMessage(), ex);
        }
    }

    /**
     * Confirm order after payment is successful.
     * This method updates the order status to CONFIRMED and clears the user's cart.
     *
     * @param orderId the order ID to confirm
     * @return the confirmed order
     */
    @Transactional
    public Order confirmOrder(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));

        if (!order.getStatus().equals(OrderStatus.PENDING)) {
            throw new RuntimeException("Only pending orders can be confirmed. Current status: " + order.getStatus());
        }

        // Update order status to CONFIRMED
        order.setStatus(OrderStatus.CONFIRMED);
        Order confirmedOrder = orderRepository.save(order);
        log.info("Order {} confirmed successfully", orderId);

        // Clear cart after successful order confirmation
        try {
            String username = order.getUsername();
            cartClient.clearCart(username);
            log.info("Cart cleared for user: {}", username);
        } catch (Exception ex) {
            log.warn("Failed to clear cart for user {}: {}", order.getUsername(), ex.getMessage());
        }

        // Fetch user email from auth-service (for notification purposes)
        String userEmail = order.getUsername() + "@smartstore.com"; // Default fallback
        try {
            String fetchedEmail = authClient.getUserByUsername(order.getUsername());
            if (fetchedEmail != null && !fetchedEmail.isBlank()) {
                userEmail = fetchedEmail;
                log.info("Fetched user email from auth-service: {}", userEmail);
            }
        } catch (Exception ex) {
            log.warn("Failed to fetch user email from auth-service, using default: {}", userEmail);
        }

        return confirmedOrder;
    }

    @Transactional
    public Order updateStatus(Long orderId, OrderStatus status) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        order.setStatus(status);
        Order updatedOrder = orderRepository.save(order);
        log.info("Order {} status updated to: {}", orderId, status);


        return updatedOrder;
    }

    public List<Order> getUserOrders(String username) {
        log.debug("Fetching orders for user: {}", username);
        return orderRepository.findByUsername(username);
    }

    /**
     * Get the total amount of an order by ID
     *
     * @param orderId the order ID
     * @return the total amount
     */
    public BigDecimal getOrderAmount(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
        log.debug("Fetched amount for order {}: {}", orderId, order.getTotalAmount());
        return order.getTotalAmount();
    }
}