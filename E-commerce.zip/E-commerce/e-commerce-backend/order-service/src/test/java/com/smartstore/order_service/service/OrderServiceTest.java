package com.smartstore.order_service.service;

import com.smartstore.order_service.client.AuthClient;
import com.smartstore.order_service.client.CartClient;
import com.smartstore.order_service.client.ProductClient;
import com.smartstore.order_service.dto.CartItemDTO;
import com.smartstore.order_service.dto.CreateOrderDTO;
import com.smartstore.order_service.exception.OutOfStockException;
import com.smartstore.order_service.model.Order;
import com.smartstore.order_service.model.OrderItem;
import com.smartstore.order_service.model.OrderStatus;
import com.smartstore.order_service.repository.OrderRepository;
import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private ProductClient productClient;

    @Mock
    private CartClient cartClient;

    @Mock
    private AuthClient authClient;


    @InjectMocks
    private OrderService orderService;

    private CreateOrderDTO createOrderDTO;
    private List<CartItemDTO> cartItems;

    @BeforeEach
    void setUp() {
        createOrderDTO = new CreateOrderDTO();
        createOrderDTO.setShippingAddress("123 Main St, Springfield");

        cartItems = new ArrayList<>();
        CartItemDTO item1 = new CartItemDTO();
        item1.setProductId(1L);
        item1.setProductName("Laptop");
        item1.setQuantity(1);
        item1.setPrice(new BigDecimal("999.99"));
        cartItems.add(item1);

        CartItemDTO item2 = new CartItemDTO();
        item2.setProductId(2L);
        item2.setProductName("Mouse");
        item2.setQuantity(2);
        item2.setPrice(new BigDecimal("25.50"));
        cartItems.add(item2);
    }

    // ==================== Place Order Tests ====================
    @Test
    void testPlaceOrderSuccessfully() {
        // Arrange
        String username = "testuser";
        when(cartClient.getUserCart(username)).thenReturn(cartItems);
        when(productClient.decrement("Laptop", 1)).thenReturn(ResponseEntity.ok(null));
        when(productClient.decrement("Mouse", 2)).thenReturn(ResponseEntity.ok(null));
        when(authClient.getUserByUsername(username)).thenReturn("testuser@smartstore.com");
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> {
            Order order = invocation.getArgument(0);
            order.setId(1L);
            return order;
        });

        // Act
        Order result = orderService.placeOrder(username, createOrderDTO);

        // Assert
        assertNotNull(result);
        assertEquals(username, result.getUsername());
        assertEquals("123 Main St, Springfield", result.getShippingAddress());
        assertEquals(OrderStatus.CONFIRMED, result.getStatus());
        assertEquals(2, result.getOrderItems().size());
        assertEquals(new BigDecimal("1050.99"), result.getTotalAmount());

        verify(cartClient, times(1)).getUserCart(username);
        verify(productClient, times(1)).decrement("Laptop", 1);
        verify(productClient, times(1)).decrement("Mouse", 2);
        verify(orderRepository, times(1)).save(any(Order.class));
        verify(cartClient, times(1)).clearCart(username);
    }

    @Test
    void testPlaceOrderWithEmptyCart() {
        // Arrange
        String username = "testuser";
        when(cartClient.getUserCart(username)).thenReturn(new ArrayList<>());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                orderService.placeOrder(username, createOrderDTO)
        );
        assertEquals("Cart is empty. Cannot place order.", exception.getMessage());
        verify(productClient, never()).decrement(anyString(), anyInt());
        verify(orderRepository, never()).save(any());
    }

    @Test
    void testPlaceOrderWithNullCart() {
        // Arrange
        String username = "testuser";
        when(cartClient.getUserCart(username)).thenReturn(null);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                orderService.placeOrder(username, createOrderDTO)
        );
        assertEquals("Cart is empty. Cannot place order.", exception.getMessage());
    }

    @Test
    void testPlaceOrderWithOutOfStock() {
        // Arrange
        String username = "testuser";
        when(cartClient.getUserCart(username)).thenReturn(cartItems);
        when(productClient.decrement("Laptop", 1)).thenThrow(createFeignException("Product out of stock"));

        // Act & Assert
        OutOfStockException exception = assertThrows(OutOfStockException.class, () ->
                orderService.placeOrder(username, createOrderDTO)
        );
        assertTrue(exception.getMessage().contains("out of stock"));
        verify(orderRepository, never()).save(any());
    }

    @Test
    void testPlaceOrderRollbackOnProductDecrementFailure() {
        // Arrange
        String username = "testuser";
        when(cartClient.getUserCart(username)).thenReturn(cartItems);
        when(productClient.decrement("Laptop", 1)).thenReturn(ResponseEntity.ok(null));
        when(productClient.decrement("Mouse", 2)).thenThrow(createFeignException("Second product failed"));
        when(productClient.increment("Laptop", 1)).thenReturn(ResponseEntity.ok(null));

        // Act & Assert
        assertThrows(OutOfStockException.class, () ->
                orderService.placeOrder(username, createOrderDTO)
        );

        // Verify rollback happened
        verify(productClient, times(1)).increment("Laptop", 1);
        verify(orderRepository, never()).save(any());
    }

    @Test
    void testPlaceOrderWithAuthServiceFailure() {
        // Arrange
        String username = "testuser";
        when(cartClient.getUserCart(username)).thenReturn(cartItems);
        when(productClient.decrement("Laptop", 1)).thenReturn(ResponseEntity.ok(null));
        when(productClient.decrement("Mouse", 2)).thenReturn(ResponseEntity.ok(null));
        when(authClient.getUserByUsername(username)).thenThrow(new RuntimeException("Auth service down"));
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> {
            Order order = invocation.getArgument(0);
            order.setId(1L);
            return order;
        });

        // Act
        Order result = orderService.placeOrder(username, createOrderDTO);

        // Assert
        assertNotNull(result);
        verify(orderRepository, times(1)).save(any(Order.class));
    }

    // ==================== Update Status Tests ====================
    @Test
    void testUpdateOrderStatusSuccessfully() {
        // Arrange
        Long orderId = 1L;
        Order order = new Order();
        order.setId(orderId);
        order.setUsername("testuser");
        order.setStatus(OrderStatus.CONFIRMED);
        order.setShippingAddress("123 Main St");
        order.setOrderItems(new ArrayList<>());

        when(orderRepository.findById(orderId)).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);
        when(authClient.getUserByUsername("testuser")).thenReturn("testuser@smartstore.com");

        // Act
        Order result = orderService.updateStatus(orderId, OrderStatus.PROCESSING);

        // Assert
        assertEquals(OrderStatus.PROCESSING, result.getStatus());
        verify(orderRepository, times(1)).findById(orderId);
        verify(orderRepository, times(1)).save(any(Order.class));
    }

    @Test
    void testUpdateOrderStatusToInTransit() {
        // Arrange
        Long orderId = 1L;
        Order order = new Order();
        order.setId(orderId);
        order.setUsername("testuser");
        order.setStatus(OrderStatus.PROCESSING);
        order.setShippingAddress("123 Main St");
        order.setOrderItems(new ArrayList<>());

        when(orderRepository.findById(orderId)).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);
        when(authClient.getUserByUsername("testuser")).thenReturn("testuser@smartstore.com");

        // Act
        Order result = orderService.updateStatus(orderId, OrderStatus.IN_TRANSIT);

        // Assert
        assertEquals(OrderStatus.IN_TRANSIT, result.getStatus());
        verify(orderRepository, times(1)).findById(orderId);
        verify(orderRepository, times(1)).save(any(Order.class));
    }

    @Test
    void testUpdateOrderStatusToDelivered() {
        // Arrange
        Long orderId = 1L;
        Order order = new Order();
        order.setId(orderId);
        order.setUsername("testuser");
        order.setStatus(OrderStatus.IN_TRANSIT);
        order.setOrderItems(new ArrayList<>());

        when(orderRepository.findById(orderId)).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        // Act
        Order result = orderService.updateStatus(orderId, OrderStatus.DELIVERED);

        // Assert
        assertEquals(OrderStatus.DELIVERED, result.getStatus());
        verify(orderRepository, times(1)).findById(orderId);
        verify(orderRepository, times(1)).save(any(Order.class));
    }

    @Test
    void testUpdateOrderStatusNotFound() {
        // Arrange
        Long orderId = 999L;
        when(orderRepository.findById(orderId)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                orderService.updateStatus(orderId, OrderStatus.PROCESSING)
        );
        assertEquals("Order not found", exception.getMessage());
        verify(orderRepository, never()).save(any());
    }

    @Test
    void testUpdateOrderStatusWithAuthServiceFailure() {
        // Arrange
        Long orderId = 1L;
        Order order = new Order();
        order.setId(orderId);
        order.setUsername("testuser");
        order.setStatus(OrderStatus.PROCESSING);
        order.setOrderItems(new ArrayList<>());

        when(orderRepository.findById(orderId)).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);
        when(authClient.getUserByUsername("testuser")).thenThrow(new RuntimeException("Auth service down"));

        // Act
        Order result = orderService.updateStatus(orderId, OrderStatus.IN_TRANSIT);

        // Assert
        assertEquals(OrderStatus.IN_TRANSIT, result.getStatus());
        verify(orderRepository, times(1)).findById(orderId);
        verify(orderRepository, times(1)).save(any(Order.class));
    }

    // ==================== Get User Orders Tests ====================
    @Test
    void testGetUserOrdersSuccessfully() {
        // Arrange
        String username = "testuser";
        List<Order> orders = new ArrayList<>();

        Order order1 = new Order();
        order1.setId(1L);
        order1.setUsername(username);
        orders.add(order1);

        Order order2 = new Order();
        order2.setId(2L);
        order2.setUsername(username);
        orders.add(order2);

        when(orderRepository.findByUsername(username)).thenReturn(orders);

        // Act
        List<Order> result = orderService.getUserOrders(username);

        // Assert
        assertEquals(2, result.size());
        assertEquals(1L, result.get(0).getId());
        assertEquals(2L, result.get(1).getId());
        verify(orderRepository, times(1)).findByUsername(username);
    }

    @Test
    void testGetUserOrdersEmpty() {
        // Arrange
        String username = "newuser";
        when(orderRepository.findByUsername(username)).thenReturn(new ArrayList<>());

        // Act
        List<Order> result = orderService.getUserOrders(username);

        // Assert
        assertTrue(result.isEmpty());
        verify(orderRepository, times(1)).findByUsername(username);
    }

    // ==================== Helper Methods ====================
    private FeignException createFeignException(String message) {

        Map<String, Collection<String>> headers = new HashMap<>();
        Request request = Request.create(
                Request.HttpMethod.GET,
                "http://test",
                headers,
                Request.Body.empty(),
                new RequestTemplate()
        );
        return new FeignException.ServiceUnavailable(message, request, null, null);

    }
}

