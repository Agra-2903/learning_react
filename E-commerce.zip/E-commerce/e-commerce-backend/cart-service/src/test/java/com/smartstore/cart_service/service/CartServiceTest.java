package com.smartstore.cart_service.service;

import com.smartstore.cart_service.client.ProductClient;
import com.smartstore.cart_service.dto.CartItemDTO;
import com.smartstore.cart_service.dto.ProductDTO;
import com.smartstore.cart_service.model.Cart;
import com.smartstore.cart_service.model.CartItem;
import com.smartstore.cart_service.repository.CartRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class CartServiceTest {

    @Mock
    private CartRepository cartRepository;

    @Mock
    private ProductClient productClient;

    @InjectMocks
    private CartService cartService;

    private Cart testCart;
    private ProductDTO testProductDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        testCart = new Cart();
        testCart.setId(1L);
        testCart.setUsername("testuser");
        testCart.setItems(new ArrayList<>());

        testProductDTO = new ProductDTO();
        testProductDTO.setId(1L);
        testProductDTO.setName("Laptop");
        testProductDTO.setPrice(new BigDecimal("999.99"));
        testProductDTO.setStock(10);
        testProductDTO.setDescription("High-performance laptop");
    }

    // ==================== Get Or Create Cart Tests ====================
    @Test
    void testGetOrCreateCartWhenCartExists() {
        // Arrange
        String username = "testuser";
        when(cartRepository.findByUsername(username)).thenReturn(Optional.of(testCart));

        // Act
        Cart result = cartService.getOrCreate(username);

        // Assert
        assertNotNull(result);
        assertEquals(username, result.getUsername());
        verify(cartRepository, times(1)).findByUsername(username);
        verify(cartRepository, never()).save(any());
    }

    @Test
    void testGetOrCreateCartWhenCartDoesNotExist() {
        // Arrange
        String username = "newuser";
        when(cartRepository.findByUsername(username)).thenReturn(Optional.empty());
        when(cartRepository.save(any(Cart.class))).thenAnswer(invocation -> {
            Cart cart = invocation.getArgument(0);
            cart.setId(2L);
            return cart;
        });

        // Act
        Cart result = cartService.getOrCreate(username);

        // Assert
        assertNotNull(result);
        assertEquals(username, result.getUsername());
        verify(cartRepository, times(1)).findByUsername(username);
        verify(cartRepository, times(1)).save(any(Cart.class));
    }

    // ==================== Add Item Tests ====================
    @Test
    void testAddItemToNewCart() {
        // Arrange
        String username = "testuser";
        CartItemDTO dto = new CartItemDTO();
        dto.setProductName("Laptop");
        dto.setQuantity(1);

        when(cartRepository.findByUsername(username)).thenReturn(Optional.empty());
        when(cartRepository.save(any(Cart.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(productClient.getProductByName("Laptop")).thenReturn(testProductDTO);

        // Act
        Cart result = cartService.addItem(username, dto);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.getItems().size());
        assertEquals("Laptop", result.getItems().get(0).getProductName());
        assertEquals(1, result.getItems().get(0).getQuantity());
        verify(cartRepository, times(2)).save(any(Cart.class));
        verify(productClient, times(1)).getProductByName("Laptop");
    }

    @Test
    void testAddItemToExistingCart() {
        // Arrange
        String username = "testuser";
        CartItemDTO dto = new CartItemDTO();
        dto.setProductName("Laptop");
        dto.setQuantity(1);

        when(cartRepository.findByUsername(username)).thenReturn(Optional.of(testCart));
        when(productClient.getProductByName("Laptop")).thenReturn(testProductDTO);
        when(cartRepository.save(any(Cart.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Cart result = cartService.addItem(username, dto);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.getItems().size());
        assertEquals("Laptop", result.getItems().get(0).getProductName());
        verify(cartRepository, times(1)).save(any(Cart.class));
    }

    @Test
    void testAddItemIncreaseQuantityIfExists() {
        // Arrange
        String username = "testuser";

        CartItem existingItem = new CartItem();
        existingItem.setProductId(1L);
        existingItem.setProductName("Laptop");
        existingItem.setQuantity(1);
        existingItem.setPrice(new BigDecimal("999.99"));
        testCart.getItems().add(existingItem);

        CartItemDTO dto = new CartItemDTO();
        dto.setProductName("Laptop");
        dto.setQuantity(1);

        when(cartRepository.findByUsername(username)).thenReturn(Optional.of(testCart));
        when(productClient.getProductByName("Laptop")).thenReturn(testProductDTO);
        when(cartRepository.save(any(Cart.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Cart result = cartService.addItem(username, dto);

        // Assert
        assertEquals(1, result.getItems().size());
        assertEquals(2, result.getItems().get(0).getQuantity()); // Quantity should increase to 2
        verify(cartRepository, times(1)).save(any(Cart.class));
    }

    // ==================== Update Item Tests ====================
    @Test
    void testUpdateItemQuantitySuccessfully() {
        // Arrange
        String username = "testuser";
        Long productId = 1L;
        int newQuantity = 5;

        CartItem item = new CartItem();
        item.setProductId(productId);
        item.setProductName("Laptop");
        item.setQuantity(1);
        testCart.getItems().add(item);

        when(cartRepository.findByUsername(username)).thenReturn(Optional.of(testCart));
        when(cartRepository.save(any(Cart.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Cart result = cartService.updateItem(username, productId, newQuantity);

        // Assert
        assertEquals(1, result.getItems().size());
        assertEquals(5, result.getItems().get(0).getQuantity());
        verify(cartRepository, times(1)).save(any(Cart.class));
    }

    @Test
    void testUpdateItemRemoveIfQuantityZero() {
        // Arrange
        String username = "testuser";
        Long productId = 1L;

        CartItem item = new CartItem();
        item.setProductId(productId);
        item.setProductName("Laptop");
        item.setQuantity(1);
        testCart.getItems().add(item);

        when(cartRepository.findByUsername(username)).thenReturn(Optional.of(testCart));
        when(cartRepository.save(any(Cart.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Cart result = cartService.updateItem(username, productId, 0);

        // Assert
        assertEquals(0, result.getItems().size());
        verify(cartRepository, times(1)).save(any(Cart.class));
    }

    @Test
    void testUpdateItemRemoveIfQuantityNegative() {
        // Arrange
        String username = "testuser";
        Long productId = 1L;

        CartItem item = new CartItem();
        item.setProductId(productId);
        item.setProductName("Laptop");
        item.setQuantity(1);
        testCart.getItems().add(item);

        when(cartRepository.findByUsername(username)).thenReturn(Optional.of(testCart));
        when(cartRepository.save(any(Cart.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Cart result = cartService.updateItem(username, productId, -1);

        // Assert
        assertEquals(0, result.getItems().size());
        verify(cartRepository, times(1)).save(any(Cart.class));
    }

    @Test
    void testUpdateItemNotFound() {
        // Arrange
        String username = "testuser";
        Long productId = 999L;

        when(cartRepository.findByUsername(username)).thenReturn(Optional.of(testCart));
        when(cartRepository.save(any(Cart.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Cart result = cartService.updateItem(username, productId, 5);

        // Assert
        assertEquals(0, result.getItems().size()); // No items to update
        verify(cartRepository, times(1)).save(any(Cart.class));
    }

    // ==================== Get User Cart Tests ====================
    @Test
    void testGetUserCartSuccessfully() {
        // Arrange
        String username = "testuser";

        CartItem item1 = new CartItem();
        item1.setProductId(1L);
        item1.setProductName("Laptop");
        item1.setQuantity(1);
        item1.setPrice(new BigDecimal("999.99"));

        CartItem item2 = new CartItem();
        item2.setProductId(2L);
        item2.setProductName("Mouse");
        item2.setQuantity(2);
        item2.setPrice(new BigDecimal("25.50"));

        testCart.getItems().add(item1);
        testCart.getItems().add(item2);

        when(cartRepository.findByUsername(username)).thenReturn(Optional.of(testCart));

        // Act
        List<CartItemDTO> result = cartService.getUserCart(username);

        // Assert
        assertEquals(2, result.size());
        assertEquals("Laptop", result.get(0).getProductName());
        assertEquals(1, result.get(0).getQuantity());
        assertEquals(new BigDecimal("999.99"), result.get(0).getTotalPrice());
        assertEquals("Mouse", result.get(1).getProductName());
        assertEquals(2, result.get(1).getQuantity());
        assertEquals(new BigDecimal("51.00"), result.get(1).getTotalPrice());
        verify(cartRepository, times(1)).findByUsername(username);
    }

    @Test
    void testGetUserCartNotFound() {
        // Arrange
        String username = "nonexistent";
        when(cartRepository.findByUsername(username)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                cartService.getUserCart(username)
        );
        assertEquals("Cart not found for user: nonexistent", exception.getMessage());
    }

    @Test
    void testGetUserCartEmpty() {
        // Arrange
        String username = "testuser";
        when(cartRepository.findByUsername(username)).thenReturn(Optional.of(testCart));

        // Act
        List<CartItemDTO> result = cartService.getUserCart(username);

        // Assert
        assertTrue(result.isEmpty());
        verify(cartRepository, times(1)).findByUsername(username);
    }

    // ==================== Clear Cart Tests ====================
    @Test
    void testClearCartSuccessfully() {
        // Arrange
        String username = "testuser";

        CartItem item = new CartItem();
        item.setProductId(1L);
        item.setProductName("Laptop");
        testCart.getItems().add(item);

        when(cartRepository.findByUsername(username)).thenReturn(Optional.of(testCart));
        when(cartRepository.save(any(Cart.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        cartService.clearCart(username);

        // Assert
        assertTrue(testCart.getItems().isEmpty());
        verify(cartRepository, times(1)).findByUsername(username);
        verify(cartRepository, times(1)).save(any(Cart.class));
    }

    @Test
    void testClearCartNotFound() {
        // Arrange
        String username = "nonexistent";
        when(cartRepository.findByUsername(username)).thenReturn(Optional.empty());

        // Act
        cartService.clearCart(username);

        // Assert
        verify(cartRepository, times(1)).findByUsername(username);
        verify(cartRepository, never()).save(any());
    }
}

