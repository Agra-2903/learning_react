package com.smartstore.cart_service.controller;

import com.smartstore.cart_service.dto.CartItemDTO;
import com.smartstore.cart_service.model.Cart;
import com.smartstore.cart_service.model.CartItem;
import com.smartstore.cart_service.service.CartService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/{username}/items")
    public ResponseEntity<Cart> addItem(@PathVariable String username, @Valid @RequestBody CartItemDTO dto) {
        return ResponseEntity.ok(cartService.addItem(username, dto));
    }

    @PutMapping("/{username}/items/{productId}")
    public ResponseEntity<Cart> updateItem(
            @PathVariable String username,
            @PathVariable Long productId,
            @RequestParam int qty
    ) {
        return ResponseEntity.ok(cartService.updateItem(username, productId, qty));
    }

    @GetMapping("/{username}")
    public ResponseEntity<Cart> getCart(@PathVariable String username) {
        return ResponseEntity.ok(cartService.getOrCreate(username));
    }

    @GetMapping("/internal/{username}")
    public List<CartItemDTO> getUserCart(@PathVariable String username) {
        return cartService.getUserCart(username);
    }

    @DeleteMapping("/internal/{username}")
    public ResponseEntity<Void> clearCart(@PathVariable String username) {
        cartService.clearCart(username);
        return ResponseEntity.ok().build();
    }
}
