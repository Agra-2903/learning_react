package com.smartstore.cart_service.service;

import com.smartstore.cart_service.client.ProductClient;
import com.smartstore.cart_service.dto.CartItemDTO;
import com.smartstore.cart_service.dto.ProductDTO;
import com.smartstore.cart_service.model.Cart;
import com.smartstore.cart_service.model.CartItem;
import com.smartstore.cart_service.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductClient productClient;

    public Cart getOrCreate(String username) {
        return cartRepository.findByUsername(username).orElseGet(() -> {
            Cart cart = new Cart();
            cart.setUsername(username);
            return cartRepository.save(cart);
        });
    }

    @Transactional
    public Cart addItem(String username, CartItemDTO dto) {
        Cart cart = getOrCreate(username);

        // Fetch product details from product-service by name
        ProductDTO productDetails = productClient.getProductByName(dto.getProductName());

        Optional<CartItem> found = cart.getItems().stream()
                .filter(i -> i.getProductId().equals(productDetails.getId()))
                .findFirst();
        if(found.isPresent()) {
            CartItem item = found.get();
            item.setQuantity(item.getQuantity() + dto.getQuantity());
        } else {
            CartItem item = new CartItem();
            item.setProductId(productDetails.getId());
            item.setProductName(productDetails.getName());
            item.setQuantity(dto.getQuantity());
            item.setPrice(productDetails.getPrice());
            item.setCart(cart);
            cart.getItems().add(item);
        }
        return cartRepository.save(cart);
    }

    @Transactional
    public Cart updateItem(String username, Long productId, int qty) {
        Cart cart = getOrCreate(username);
        cart.getItems().stream()
                .filter(i -> i.getProductId().equals(productId))
                .findFirst()
                .ifPresent(i -> {
                    if(qty <= 0) cart.getItems().remove(i);
                    else i.setQuantity(qty);
                });
        return cartRepository.save(cart);
    }

    public List<CartItemDTO> getUserCart(String username) {
        Cart cart = cartRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Cart not found for user: " + username));

        return cart.getItems()
                .stream()
                .map(item -> {
                    CartItemDTO dto = new CartItemDTO();
                    dto.setProductId(item.getProductId());
                    dto.setProductName(item.getProductName());
                    dto.setQuantity(item.getQuantity());
                    dto.setPrice(item.getPrice());

                    dto.setTotalPrice(
                            item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity()))
                    );

                    return dto;
                })
                .toList();
    }

    public void clearCart(String username) {
        cartRepository.findByUsername(username).ifPresent(cart -> {
            cart.getItems().clear();
            cartRepository.save(cart);
        });
    }
}
