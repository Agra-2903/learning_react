package com.smartstore.cart_service.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CartItemDTO {
    @NotNull(message = "Product ID cannot be null")
    @Positive(message = "Product ID must be greater than zero")
    private Long productId;

    @NotBlank(message = "Product name cannot be blank")
    @Size(min = 1, max = 500, message = "Product name must be between 1 and 500 characters")
    private String productName;

    @NotNull(message = "Quantity is required")
    @Min(value = 1, message = "Quantity must be at least 1")
    @Max(value = 10000, message = "Quantity cannot exceed 10000")
    private Integer quantity;

    @NotNull(message = "Price cannot be null")
    @DecimalMin(value = "0.01", message = "Price must be at least 0.01")
    @DecimalMax(value = "9999999.99", message = "Price cannot exceed 9999999.99")
    private BigDecimal price;

    private BigDecimal totalPrice;
}
