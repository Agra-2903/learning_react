package com.smartstore.payment_service.service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;
import com.smartstore.payment_service.client.OrderClient;
import com.smartstore.payment_service.dto.CreatePaymentRequest;
import com.smartstore.payment_service.dto.CreatePaymentResponse;
import com.smartstore.payment_service.dto.VerifyPaymentRequest;
import com.smartstore.payment_service.model.Payment;
import com.smartstore.payment_service.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final RazorpayClient razorpayClient;
    private final OrderClient orderClient;

    @Value("${razorpay.key.id}")
    private String razorpayKey;

    @Value("${razorpay.key.secret}")
    private String razorpaySecret;

    public CreatePaymentResponse createPayment(CreatePaymentRequest request) throws RazorpayException {
        // Amount is passed directly in request to avoid circular dependency with order-service
        BigDecimal amount = request.getAmount();

        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("Invalid payment amount: " + amount);
        }

        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", amount.multiply(BigDecimal.valueOf(100))); // Amount in paise
        orderRequest.put("currency", "INR");

        Order razorpayOrder = razorpayClient.orders.create(orderRequest);

        Payment payment = new Payment();
        payment.setOrderId(request.getOrderId());
        payment.setAmount(amount);
        payment.setCurrency("INR");
        payment.setPaymentStatus("PENDING");
        payment.setRazorpayOrderId(razorpayOrder.get("id"));

        paymentRepository.save(payment);

        return new CreatePaymentResponse(
            payment.getId(),
            razorpayOrder.get("id"),
            amount.multiply(BigDecimal.valueOf(100)),
            "INR",
            razorpayKey
        );
    }

    public void verifyPayment(VerifyPaymentRequest request) throws RazorpayException{

        String data = request.getRazorpayOrderId() + '|' + request.getRazorpayPaymentId();

        boolean isSignatureValid = Utils.verifySignature(
            data,
            razorpaySecret,
            request.getRazorpaySignature()
        );

        if (!isSignatureValid) {
            log.error("Invalid signature for payment verification");
            throw new RuntimeException("Invalid payment signature");
        }

        Payment payment = paymentRepository.findByRazorpayOrderId(
            request.getRazorpayOrderId())
            .orElseThrow(() -> new RuntimeException("Payment not found"));

        payment.setRazorpayPaymentId(request.getRazorpayPaymentId());
        payment.setPaymentStatus("SUCCESS");

        paymentRepository.save(payment);

        orderClient.updateOrderStatus(payment.getOrderId(), "PAID");
        log.info("Payment verified successfully for order: {}", payment.getOrderId());
    }

    /**
     * Validates payment method for an order
     * Currently supports:
     * - CASH_ON_DELIVERY: Always valid
     * - RAZORPAY: Valid if amount and order ID are present
     *
     * @param orderId the order ID
     * @param paymentMethod the payment method (e.g., CASH_ON_DELIVERY, RAZORPAY)
     * @param amount the payment amount
     * @return true if payment method is valid, false otherwise
     */
    public boolean validatePaymentMethod(Long orderId, String paymentMethod, BigDecimal amount) {
        log.info("Validating payment method: {} for order: {} with amount: {}", paymentMethod, orderId, amount);

        if (paymentMethod == null || paymentMethod.trim().isEmpty()) {
            log.warn("Payment method is null or empty for order: {}", orderId);
            return false;
        }

        String method = paymentMethod.toUpperCase().trim();

        // Cash on Delivery is always valid
        if ("CASH_ON_DELIVERY".equals(method)) {
            log.info("Payment method CASH_ON_DELIVERY validated successfully for order: {}", orderId);
            return true;
        }

        // Razorpay validation
        if ("RAZORPAY".equals(method) || "ONLINE".equals(method)) {
            // Check if amount is valid
            if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
                log.warn("Invalid amount for Razorpay payment: {} for order: {}", amount, orderId);
                return false;
            }
            log.info("Payment method {} validated successfully for order: {}", method, orderId);
            return true;
        }

        // Debit Card, Credit Card, etc.
        if ("DEBIT_CARD".equals(method) || "CREDIT_CARD".equals(method) || "UPI".equals(method)) {
            if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
                log.warn("Invalid amount for {} payment: {} for order: {}", method, amount, orderId);
                return false;
            }
            log.info("Payment method {} validated successfully for order: {}", method, orderId);
            return true;
        }

        log.warn("Unknown payment method: {} for order: {}", method, orderId);
        return false;
    }
}
