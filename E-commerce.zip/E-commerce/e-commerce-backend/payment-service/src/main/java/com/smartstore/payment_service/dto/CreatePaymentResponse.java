package com.smartstore.payment_service.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
public class CreatePaymentResponse {
    @NotNull(message = "Payment ID cannot be null")
    @Positive(message = "Payment ID must be greater than zero")
    private Long paymentId;

    @NotBlank(message = "Razorpay Order ID is required")
    @Size(min = 10, max = 100, message = "Razorpay Order ID must be between 10 and 100 characters")
    private String razorpayOrderId;

    @NotNull(message = "Amount cannot be null")
    @DecimalMin(value = "0.01", message = "Amount must be at least 0.01")
    @DecimalMax(value = "9999999.99", message = "Amount cannot exceed 9999999.99")
    private BigDecimal amount;

    @NotBlank(message = "Currency is required")
    @Size(min = 3, max = 3, message = "Currency code must be 3 characters")
    @Pattern(regexp = "^[A-Z]{3}$", message = "Currency code must be 3 uppercase letters")
    private String currency;

    @NotBlank(message = "Razorpay Key is required")
    @Size(min = 10, max = 200, message = "Razorpay Key must be between 10 and 200 characters")
    private String razorpayKey;
}
