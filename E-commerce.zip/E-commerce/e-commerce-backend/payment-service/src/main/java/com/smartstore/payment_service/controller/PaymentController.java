package com.smartstore.payment_service.controller;

import com.razorpay.RazorpayException;
import com.smartstore.payment_service.dto.CreatePaymentRequest;
import com.smartstore.payment_service.dto.CreatePaymentResponse;
import com.smartstore.payment_service.dto.PaymentValidationRequest;
import com.smartstore.payment_service.dto.VerifyPaymentRequest;
import com.smartstore.payment_service.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping("/create")
    public ResponseEntity<CreatePaymentResponse> createPayment(@RequestBody CreatePaymentRequest createPaymentRequest) throws RazorpayException {
        return ResponseEntity.ok(paymentService.createPayment(createPaymentRequest));
    }

    @PostMapping("/verify")
    public ResponseEntity<String> verifyPayment(@RequestBody VerifyPaymentRequest verifyPaymentRequest) throws RazorpayException{
        paymentService.verifyPayment(verifyPaymentRequest);
        return ResponseEntity.ok("Payment verified successfully");
    }

    @PostMapping("/validate")
    public ResponseEntity<Boolean> validatePaymentMethod(@RequestBody PaymentValidationRequest request) {
        boolean isValid = paymentService.validatePaymentMethod(
            request.getOrderId(),
            request.getPaymentMethod(),
            request.getAmount()
        );
        return ResponseEntity.ok(isValid);
    }
}

