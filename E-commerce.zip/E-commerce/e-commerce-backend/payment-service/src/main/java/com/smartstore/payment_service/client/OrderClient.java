package com.smartstore.payment_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

@FeignClient(name = "order-service", url = "http://localhost:8082")
public interface OrderClient {

    @GetMapping("/api/orders/{orderId}/amount")
    BigDecimal getOrderAmount(@PathVariable Long orderId);

    @PutMapping("/api/orders/{orderId}/status")
    void updateOrderStatus(@PathVariable Long orderId, @RequestParam String status);
}
