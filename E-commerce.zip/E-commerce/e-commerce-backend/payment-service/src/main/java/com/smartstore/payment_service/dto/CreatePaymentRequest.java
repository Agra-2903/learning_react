package com.smartstore.payment_service.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreatePaymentRequest {
    @NotNull(message = "Order ID cannot be null")
    @Positive(message = "Order ID must be greater than zero")
    private Long orderId;

    @NotNull(message = "Amount cannot be null")
    @DecimalMin(value = "0.01", message = "Amount must be at least 0.01")
    @DecimalMax(value = "9999999.99", message = "Amount cannot exceed 9999999.99")
    private BigDecimal amount;

    @NotBlank(message = "Payment method is required")
    @Size(min = 3, max = 50, message = "Payment method must be between 3 and 50 characters")
    @Pattern(regexp = "^[A-Z_]+$", message = "Payment method must be uppercase letters and underscores only")
    private String paymentMethod;
}
