package com.smartstore.payment_service.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class VerifyPaymentRequest {
    @NotBlank(message = "Razorpay Payment ID is required")
    @Size(min = 10, max = 100, message = "Razorpay Payment ID must be between 10 and 100 characters")
    private String razorpayPaymentId;

    @NotBlank(message = "Razorpay Order ID is required")
    @Size(min = 10, max = 100, message = "Razorpay Order ID must be between 10 and 100 characters")
    private String razorpayOrderId;

    @NotBlank(message = "Razorpay Signature is required")
    @Size(min = 10, max = 500, message = "Razorpay Signature must be between 10 and 500 characters")
    private String razorpaySignature;

    @NotNull(message = "Order ID cannot be null")
    @Positive(message = "Order ID must be greater than zero")
    private Long orderId;
}
