package com.smartstore.payment_service.exception;

public class PaymentException {
}
