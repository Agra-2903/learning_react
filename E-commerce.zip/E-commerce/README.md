# E-Commerce Application

## Quick Start

### 1. Start Backend Services
```bash
# Run this first
start-backend-simple.bat
```

### 2. Check Services Status
```bash
# Wait 2 minutes, then run this
check-services.bat
```

### 3. Start Frontend
```bash
cd e-commerce-frontend
npm run dev
```

## Troubleshooting

### Backend Not Starting
- Ensure Java 17+ is installed
- Ensure Maven is installed
- Check if ports 8080-8083 are free
- Run services individually if needed

### Connection Refused Error
- Backend services are not running
- Run `check-services.bat` to verify
- Restart services with `start-backend-simple.bat`

### Database Issues
- Ensure MySQL is running on localhost:3306
- Check database credentials in application.properties files

## Service Ports
- API Gateway: 8080
- Auth Service: 8081  
- Product Service: 8082
- Order Service: 8083
- Frontend: 3000